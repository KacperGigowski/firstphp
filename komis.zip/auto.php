<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Komis samochodowy</title>
    <link rel="stylesheet" href="auto.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div id='baner'>
    <h1>SAMOCHODY</h1>
    </div>
    
    <div id='lewy'>
    <h2>Wykaz samochodów</h2>
    <h3>Zamówienia</h3>
    </div>
    
    <div id='prawy'>
    <h3>Pełne dane: Fiat</h3>
    </div>

    <div id='stopa'>
    <table id='tabela'>
  <tr>
    <td>Kwerendy</td>
    <td>Autor: Kacper "GiGi" Gigowski</td>
    <td><img src='auto.png' width="150px" height="50px"></td>
  </tr>
</table>
    </div>

</body>
</html>